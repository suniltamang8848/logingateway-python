# logingateway
This contains the python script running which we can easily connect to home network without retyping password.
